/*
 * spi2.h
 *
 *  Created on: Dec 25, 2025
 *      Author: mukslinuxmachine
 */

#ifndef INC_SPI_H_
#define INC_SPI_H_


#include "main.h"

void spi_init(void);
void spi_transmit(uint8_t * data, int len);
void spi_recieve(uint8_t * data, int len);




#endif /* INC_SPI_H_ */
