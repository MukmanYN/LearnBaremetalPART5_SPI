/*
 * gpio.h
 *
 *  Created on: Dec 25, 2025
 *      Author: mukslinuxmachine
 */

#ifndef INC_GPIO_H_
#define INC_GPIO_H_

#include "main.h"

void gpio_init(void);
void gpio_write_on(void);
void gpio_write_off(void);


#endif /* INC_GPIO_H_ */
