/*
 * gpio.c
 *
 *  Created on: Dec 25, 2025
 *      Author: mukslinuxmachine
 */


#include "gpio.h"

#define GPIOAEN  (1<<0);
#define GPIOBEN  (1<<1);
#define GPIOCEN (1<<2)
void gpio_init(void){

	RCC->AHB1ENR |=  GPIOAEN;  // enable GPIOA

	RCC->AHB1ENR |= GPIOBEN;  // enable GPIOB

	RCC->AHB1ENR |= GPIOCEN;  // enable GPIOc

	GPIOC->MODER  |=  (1U<< 3);  // GPIOC mode pin c1 MOSI set to AF
	GPIOC->MODER  &= ~(1U<<2);

	GPIOC->MODER  |=  (1U<< 5);  // GPIOC mode pin c2 MISO set to AF
	GPIOC->MODER  &= ~(1U<<4);

	GPIOB->MODER  |=  (1U<< 21);  // GPIOB mode pin b10 SCLK set to AF
	GPIOB->MODER  &= ~(1U<<20);

	GPIOA->MODER &= ~(1U<< 19);  // GPIOA a9 is set to output chip select
	GPIOA->MODER |= (1U<< 18);

	// GPIOA->AFR[0] is 0 - 7

	GPIOB->AFR[1] |=  (0b0101  << 8);  // AF5 pin spi SCLK

	GPIOC->AFR[0] |=  (0b0101  << 8);  // AF5 pin spi MISO

	GPIOC->AFR[0] |=  (0b0111  << 4);  // AF7 pin spi MOSI

	GPIOA->ODR |= (1U<< 9);  // enable as output A9


}

void gpio_write_on(void){
	GPIOA->ODR |= (1U<< 9);  // enable as output A9
}

void gpio_write_off(void){
	GPIOA->ODR &= ~(1U<< 9);  // enable as output A9
}


