/*
 * spi2.c
 *
 *  Created on: Dec 25, 2025
 *      Author: mukslinuxmachine
 */
#include <spi.h>



#define SPI2EN   (1<<14)

void spi_init(void){


	// set GPIO SCL , MOSI , MISO TO AF pins in GPIO init

	RCC->APB1ENR |=  SPI2EN;  // enable spi

	SPI2->CR1   |= (0b010  << 3) ; // set prescalar to 8

	SPI2->CR1  |= (1u<< 1); // CPOL  set idle high

	SPI2->CR1  |= (1u << 0); // CPHASE  set to 2nd edge data captue

	SPI2->CR1  |= (1u << 2);  // master selection

	//DFF is 8 bit = =0
    SPI2->CR1 |= (1U<<9);          // SSM = 1  (software slave management) “Ignore the physical NSS pin. I’ll manage it in software.”
    SPI2->CR1 |= (1U<<8);          // SSI = 1  (internal NSS high)  forces CS pin high


	SPI2->CR1 |= (1u<< 6); // enable spi

}


#define  BSY (1u<< 7)
#define RXNE (1u<<0)
#define TXE (1u<<1)

static inline uint8_t spi1_xfer8(uint8_t tx)
{

    while (!(SPI2->SR & SPI_SR_TXE)) {} // wait till txe not busy
       *(volatile uint8_t *)&SPI2->DR = tx;  // send register address
       while (!(SPI2->SR & SPI_SR_RXNE)) {} // wait until recieve not empty
       return *(volatile uint8_t *)&SPI2->DR;   // receive
}




void spi_transmit(uint8_t * data, int len){

	for (int i = 0; i < len; i++)
	    {
	        (void)spi1_xfer8(data[i]);  // send register address
	    }
	    while (SPI2->SR & SPI_SR_BSY) {}  // wait until spi not busy
}

void spi_recieve(uint8_t * data, int len){

	for (int i = 0; i < len; i++)
	    {
	        data[i] = spi1_xfer8(0x00);   // or 0xFF depending on device
	    }
	    while (SPI2->SR & SPI_SR_BSY) {}

}


